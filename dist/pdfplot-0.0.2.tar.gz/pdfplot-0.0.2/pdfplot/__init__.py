from .pdfplot import *

"""
pyexample.

An example python library.
"""

__version__ = "0.0.2"
__author__ = 'Sauhaarda Chowdhuri'